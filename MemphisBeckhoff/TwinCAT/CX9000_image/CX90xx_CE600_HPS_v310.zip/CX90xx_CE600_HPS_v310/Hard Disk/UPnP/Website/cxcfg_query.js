function query_readwrite(index, subindex, flag, len, type, data, id, loop)
{
        if ((!g_req_in_use && !loop) || (!g_l_req_in_use && loop))
        {
                var ndata = new Array();
                ndata = prepare_data(data,type,0,ndata);

                debugln("Sending ReadWrite Query at index <b>"+index+"</b>,<b>"+subindex+"</b> with ID: <b>"+id+"</b>");

                var names = Array();
                names[0] = "netId";
                names[1] = "nPort";
                names[2] = "indexGroup";
                names[3] = "IndexOffset";
                names[4] = "cbRdLen";
                names[5] = "pwrData";
                
                var values = Array();
                values[0] = "";
                values[1] = "0";
                values[2] = "0";
                values[3] = get_mdpoffset(index,subindex,flag);
                values[4] = len;
                values[5] = encode_base64(ndata);

                query_full("ReadWrite",names,values,loop);
                g_requests[0] = new Request("ReadWrite",index,subindex,flag,0,-1,0,id,false);
                
                if (loop)
                    g_l_requests[0] = new Request("ReadWrite",index,subindex,flag,0,-1,0,id,false);
                else g_requests[0] = new Request("ReadWrite",index,subindex,flag,0,-1,0,id,false);

        }
        else
        {
          window.setTimeout("query_readwrite('"+index+"','"+subindex+"','"+flag+"','"+len+"','"+type+"','"+data+"','"+id+"',"+loop+")", 100);
        }
}

function query_readmultiple(a_index, a_subindex, a_flags, a_len, a_type, iarr, id, loop)
{
        if ((!g_req_in_use && !loop) || (!g_l_req_in_use && loop))
        {
                var isStr=false;
                var ci = "";
                if ((typeof id) == 'string') isStr = true;
          
                debugln("Sending Readmultiple Query with "+a_index.length+" items (first index: <b>"+a_index[0]+"</b>,<b>"+a_subindex[0]+"</b>) and ID: <b>"+id+"</b>");
                var data = Array();
                var j = 0;
                if (loop)
                    g_l_requests = new Array();
                else g_requests = new Array();
                
                var clen = 0;
                for (var i = 0; i < a_index.length; i++)
                {    
                    if (a_index[i]!=-1)
                    {
                        //add group (0)
                        data[j++] = 0;
                        data[j++] = 0;
                        data[j++] = 0;
                        data[j++] = 0;
                        
                        //add offset
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],a_flags[i]) >> (0)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],a_flags[i]) >> (8)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],a_flags[i]) >> (16)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],a_flags[i]) >> (24)),10));
                        
                        //add len
                        data[j++] = to_byte(parseInt((a_len[i] >> (0)),10));
                        data[j++] = to_byte(parseInt((a_len[i] >> (8)),10));
                        data[j++] = to_byte(parseInt((a_len[i] >> (16)),10));
                        data[j++] = to_byte(parseInt((a_len[i] >> (24)),10));
                                               
                        if (iarr!=-1)
                                ci = iarr[i]
                        else ci = iarr;

                        if (loop)
                            g_l_requests[clen] = new Request("ReadMultiple",a_index[i],a_subindex[i],a_flags[i],a_len[i],a_type[i],ci,(isStr?id:id[i]),false);
                        else g_requests[clen] = new Request("ReadMultiple",a_index[i],a_subindex[i],a_flags[i],a_len[i],a_type[i],ci,(isStr?id:id[i]),false);
                        clen++;
                    }    
                }
                
                var names = Array();
                names[0] = "netId";
                names[1] = "nPort";
                names[2] = "indexGroup";
                names[3] = "IndexOffset";
                names[4] = "cbRdLen";
                names[5] = "pwrData";
                
                var values = Array();
                values[0] = "";
                values[1] = "0";
                values[2] = 61568;
                values[3] = clen;
                values[4] = clen;
                values[5] = encode_base64(data);
                query_full("ReadWrite",names,values,loop);
        }
        else
        {
            tries++;
            if (tries > retries)
            {
                if (loop) g_l_req_in_use = false;
                else g_req_in_use = false;
                tries=0;
            }
            window.setTimeout("query_readmultiple('"+a_index+"','"+a_subindex+"','"+a_flags+"','"+a_len+"','"+a_type+"','"+iarr+"','"+id+"',"+loop+")", 500);
        }
}



function query_writemultiple(a_index, a_subindex, a_type, a_length, a_data, id)
{
        if (!g_req_in_use)
        {       
                debugln("Sending Writemultiple Query at index with "+a_index.length+" items (first index: <b>"+a_index[0]+"</b>,<b>"+a_subindex[0]+"</b>) and ID: <b>"+id+"</b>");
                var data = Array();
                var j = 0;
                g_requests = new Array();

                var datatmp = Array();
                
                for (var i = 0; i < a_index.length; i++)
                {                       
                        //add group (0)
                        data[j++] = 0;
                        data[j++] = 0;
                        data[j++] = 0;
                        data[j++] = 0;
                        
                        
                        //add offset
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],0) >> (0)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],0) >> (8)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],0) >> (16)),10));
                        data[j++] = to_byte(parseInt((get_mdpoffset(a_index[i],a_subindex[i],0) >> (24)),10));
                        
                        if (a_type[i]=="string")
                               a_length[i] = a_data[i].length;
                        //add len
                        data[j++] = to_byte(parseInt((a_length[i] >> (0)),10));
                        data[j++] = to_byte(parseInt((a_length[i] >> (8)),10));
                        data[j++] = to_byte(parseInt((a_length[i] >> (16)),10));
                        data[j++] = to_byte(parseInt((a_length[i] >> (24)),10));                       
                                                       
                        g_requests[i] = new Request("WriteMultiple",a_index[i],a_subindex[i],0,0,0,-1,id,false);

                        datatmp = prepare_data(a_data[i],a_type[i],a_length[i],datatmp);
                }

                data = data.concat(datatmp);
                
                var names = Array();
                names[0] = "netId";
                names[1] = "nPort";
                names[2] = "indexGroup";
                names[3] = "IndexOffset";
                names[4] = "cbRdLen";
                names[5] = "pwrData";
                
                var values = Array();
                values[0] = "";
                values[1] = "0";
                values[2] = 61569;
                values[3] = a_index.length;
                values[4] = a_index.length;
                values[5] = encode_base64(data);
                
                query_full("ReadWrite",names,values,false);
        }
        else window.setTimeout("query_writemultiple('"+a_index+"','"+a_subindex+"','"+a_type+"','"+a_length+"','"+a_data+"','"+id+"')", 100);
}

function query_write(index, subindex, flag, data, type, refresh, id)
{
        if (!g_req_in_use)
        {
                var ndata = new Array();
                ndata = prepare_data(data,type,0,ndata);
                g_requests = new Array();
                
                var names = Array();
                names[0] = "netId";
                names[1] = "nPort";
                names[2] = "indexGroup";
                names[3] = "IndexOffset";
                names[4] = "pData";
                
                var values = Array();
                values[0] = "";
                values[1] = "0";
                values[2] = "0";
                values[3] = get_mdpoffset(index,subindex,0);
                values[4] = encode_base64(ndata);
                g_requests[0] = new Request("Write",index,subindex,flag,0,-1,0,id,refresh);
                
                debugln("Sending Write Query at index <b>"+index+"</b>,<b>"+subindex+"</b>");                   
                query_full("Write",names,values,false);
        }
        else window.setTimeout("query_write('"+index+"','"+subindex+"','"+flag+"','"+data+"','"+type+"','"+refresh+"', '"+id+"')", 100);
        
}

function query_read(index, subindex, flags, len, type, refresh, id)
{
        if (!g_req_in_use)
        {
                g_requests = new Array();
                debugln("Sending Read Query at index <b>"+index+"</b>,<b>"+subindex+"</b> with ID: <b>"+id+"</b>");
                var names = Array();
                names[0] = "netId";
                names[1] = "nPort";
                names[2] = "indexGroup";
                names[3] = "IndexOffset";
                names[4] = "cbRdLen";
                
                var values = Array();
                values[0] = "";
                values[1] = "0";
                values[2] = "0";
                values[3] = get_mdpoffset(index,subindex,flags);
                values[4] = len;
                
                query_full("Read",names,values,false);
                g_requests[0] = new Request("Read",index,subindex,flags,0,type,-1,id,refresh);
        }
        else window.setTimeout("query_read('"+index+"','"+subindex+"','"+flags+"','"+len+"','"+type+"','"+refresh+"')", 100);
}

function query_sr(method, loop, sr)
{
    if ((!g_req_in_use && !loop) || (!g_l_req_in_use && loop))
    {
        g_db_sr = sr;
        g_method = method;
        try
        {
                if (loop) g_l_req_in_use = true;
                else g_req_in_use = true;
                      
                if (loop)
                {
                    loadXMLDoc(device_url, lreq, processReqChangeLoop);
                    lreq.setRequestHeader("SOAPAction", "urn:beckhoff.com:service:cxconfig:1#"+method);
                    lreq.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
                    lreq.setRequestHeader("Content-Length", sr.length);
                    lreq.send(sr);
                }
                else
                {
                    loadXMLDoc(device_url, req, processReqChange);
                    req.setRequestHeader("SOAPAction", "urn:beckhoff.com:service:cxconfig:1#"+method);
                    req.setRequestHeader("Content-Type", "text/xml; charset=utf-8");
                    req.setRequestHeader("Content-Length", sr.length);
                    req.send(sr);
               }
        }
        catch (e) //object is in use, try later
        {
                show_info("Error: "+(e.description!=null?e.description:e),"red");
                errors++;
                if (errors<maxerrors)
                  window.setTimeout("query_sr('"+method+"','"+false+"','"+sr+"')", 100);
                else load_end();
                return;
        }
    } 
    else
    {
        tries++;
        if (tries > retries)
        {
            if (loop) g_l_req_in_use = false;
            else g_req_in_use = false;
            tries=0;
        }
        window.setTimeout("query_sr('"+method+"','"+false+"','"+sr+"')", 100);
        
    }
}
function query_full(method,names,values,loop)
{     
      var sr = "<?xml version=\"1.0\" encoding=\"utf-8\"?>" + 
               "<s:Envelope s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\">" +
               "<s:Body><u:"+method+" xmlns:u=\"urn:beckhoff.com:service:cxconfig:1\">";

       
      if (names)
      {
              for (var i=0; i<names.length; i++)
              {
                      if (names[i]!="Error" && names[i][0]!="-")
                              sr+="<"+names[i]+">"+values[i]+"</"+names[i]+">";
              }
      }                  
      
      sr+="</u:"+method+"></s:Body></s:Envelope>";
      
      query_sr(method, loop,sr);     
}
