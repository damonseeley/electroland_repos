function getPosition(obj)
{
  var pos = { x:0, y:0 };
  
  if(obj.offsetParent)
  {
    do
    {
      pos.x += obj.offsetLeft;
      pos.y += obj.offsetTop;
    }
    while ((obj = obj.offsetParent)!=null);
  }
  else if (obj.x)
  {
    pos.x = obj.x;
    pos.y = obj.y;
  }

  return pos;
}

function change_hostname()
{
    var value = document.getElementById("Hostname").firstChild.innerHTML; 
    query_write(0x1008, 0, 0, value, "string", true)
    rebootWithQuestion("Settings saved."); 
}

function rebootWithQuestion(text)
{
        if(confirm(text+" You need to reboot for changes to take effect. Reboot now?"))
        {
            addquery="";
            doReboot(false,true);    
        }
}

function get_dots(count)
{
        var dots = "...";
        for (var i = 0; i < count; i++)
        {
                dots += ".";
        }
        return dots;
}


function doReboot(need_confirm)
{
        if (need_confirm)
                answer = confirm("Do you really want to reboot the device?")
        else answer = 1;
        if (answer != 0)
        {
              if (rebootindex==-1)
              {
                  show_info("Error: Unable to reboot","red");
                  return;
              }  
              reboottext = "Rebooting";
              is_rebooting = true;
              query_write(rebootindex, 1, 0, 0, "int", false);
              
              if (g_interval) window.clearInterval(g_interval);
              g_interval = window.setInterval(RebootLoop, 5000);
        }
}

function RebootLoop()
{
        if (is_rebooting)
        {
                document.getElementById("current").innerHTML="<p align=\"center\"><font size=\"+1\">"+reboottext+"...<br>be patient.<br>"+get_dots(rebootcount)+"</font></p>";
                rebootcount++;

                var idx = new Array(1); 
                idx[0] = 0x1008;
                var sidx = new Array(1);
                sidx[0] = 0;
                var flag = new Array(1); 
                flag[0] = 0;
                var len = new Array(1);
                len[0] = 80;
                var type = new Array(1);
                type[0] = "string";
                g_l_req_in_use = false;
                query_readmultiple(idx,sidx,flag,len,type,new Array(),"reboot",processReqChangeLoop);
        } 
}



function loadXMLDoc(url, xmlhttp, func) 
{
        xmlhttp.onreadystatechange = function () {};
        xmlhttp.abort();
        xmlhttp.onreadystatechange = func;
        xmlhttp.open("POST", url, true);
}

function createXMLHttpObject()
{
        try { return new ActiveXObject("Msxml2.XMLHTTP"); } catch (e) {}
        try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch (e) {}
        try { return new XMLHttpRequest(); } catch(e) {}
        return null;
}

function cpuloop()
{
    if (mod.type=="CPU")
    {
        var idx = new Array((mod.index+1).toString());
        var sidx = new Array("2");
        var flag = new Array("0");
        var len = new Array("2");
        var type = new Array("int");
        var i = new Array("1");

        query_readmultiple(idx,sidx,flag,len,type,i,"CPU",true);
    }
}

function memoryloop()
{
    if (mod.type=="Memory")
    {
        var idx = new Array((mod.index+1),(mod.index+1),(mod.index+1),(mod.index+1),(mod.index+1));
        var sidx = new Array(1,2,3,4,5);
        var flag = new Array(0,0,0,0,0);
        var len = new Array(4,4,4,4,4);
        var type = new Array("int","int","int","int","int");
        var i = new Array("0","1","2","3","4");

        query_readmultiple(idx,sidx,flag,len,type,i,"Memory",true); 
    }
}

function favloop()
{
  if (mod.type=="PLC" && g_ndata!=null)
  {
      if (!g_l_req_in_use)
        query_readwrite(browseindex+4,1,2,buffer_size,"data",g_ndata,"GetFavVals", true);
  }
  else
  {
    g_ndata = null;
  }
}

function in_array(arr, elem)
{
  for (var i = 0; i < arr.length; i++)
  {
    if (arr[i]==elem) return true;
  }
  return false;
}

Array.prototype.deleteByElem = function(elem)
{
   for (var x = 0; x < this.length; ++x)
	 {  
      if (this[x] == elem)
		  {
				this.deleteByKey(x);
				break;
      }
    }
};

Array.prototype.deleteByKey = function(key)
{
    for (var x = 0; x < this.length; ++x)
	 {
        if (x >= key)
		  {
			this[x] = this[x + 1];
        }

    }
	 this.pop();
};


function runfunction(i,id,f)
{
        if (cancelreturn)
        {
          cancelreturn = false;
          return;
        }
        mod.run(i,id,f);
}


function show_type(id)
{
     if (!is_rebooting)
     {
       if (!g_req_in_use)
       {
               box_close();
               clear_info();
               if (id!=-1)
               {
                 if (id>=0)
                 {
                    document.getElementById("current").innerHTML = "";      
                    mod = new Module(mod_list[id]);
                 }
                 debugln("mod.show function");
                 if(!mod.hide) 
								 		mod.show(true);
               }
               else show_overview();
  
  
               if (id!=-2)
               {
                 document.getElementById("m"+lastmenu+"i").className="";
                 document.getElementById("m"+lastmenu).className="";
    
                 document.getElementById("m"+id+"i").className="menuSelected";
                 document.getElementById("m"+id).className="menuSelected";
  
                 lastmenu = id;
               }
       }
       else
       {
          window.setTimeout("show_type('"+id+"');", 200);
       }
     } 
}


function count_types (type)
{
        var count = 0;
        for (var i = 0; i < mod_count; i++)
        {
                if (mod_list[i].type==type)
                        count++;
        }
        return count;
}

function get_object (type)
{
        for (var i = 0; i < mod_count; i++)
        {
                if (mod_list[i].type==type)
                        return i;
        }
        return -1;
}


function favchange()
{
     var sel = document.getElementById("favgroups").options[document.getElementById("favgroups").selectedIndex].value;
     
     if (sel=="none")
     {
        g_ndata = null;
        document.getElementById("cFavList").innerHTML = "";
        document.getElementById("function0").style.display = "";
     }
     else
     {
        var ndata = new Array();
        favgroup = "PLC_FAVORITE_GROUP."+sel;
        ndata = prepare_data(16+favgroup.length+1,"int",4,ndata); //cbData
        ndata = prepare_data(0,"int",4,ndata); //hContinue
        ndata = prepare_data(buffer_size,"int",4,ndata); //maxReadLen
        ndata = prepare_data(favgroup.length+1,"int",4,ndata); //cbPath
        ndata = prepare_data(favgroup,"string",0,ndata);
        full_buffer = new Array();
        full_buffer_param = favgroup;
                                                              
        query_readwrite(systemdsindex,1,2,buffer_size,"data",ndata, "GetFavList");
        document.getElementById("function0").style.display = "none";
     }
}

function getFav(id)
{
      var ndata = new Array();
      var favgroup = "PLC_FAVORITE_GROUP";
      ndata = prepare_data(16+favgroup.length+1,"int",4,ndata); //cbData
      ndata = prepare_data(0,"int",4,ndata); //hContinue
      ndata = prepare_data(buffer_size,"int",4,ndata); //maxReadLen
      ndata = prepare_data(favgroup.length+1,"int",4,ndata); //cbPath
      ndata = prepare_data(favgroup,"string",0,ndata);
      full_buffer = new Array();
      full_buffer_param = favgroup;
          
      query_readwrite(systemdsindex,1,2,buffer_size,"data",ndata,id,false);
}


function load_end()
{
  document.getElementById("load_box").style.display="none";
  document.getElementById("overlay").style.display="none";

  if(fixDocumentSizeLoopID!=undefined)
    window.clearTimeout(fixDocumentSizeLoopID);
}

function load_start()
{	
	fixDocumentSizeLoop(500);
	document.getElementById("load_box").style.display=""; 
	document.getElementById("overlay").style.display="";
}

function fixOverlaySize()
{
	document.getElementById("overlay").style.height = (document.body.parentNode.scrollHeight)+"px";
 	document.getElementById("overlay").style.width = (document.body.parentNode.scrollWidth)+"px";
}

function fixLoadBoxSize()
{	
	document.getElementById("load_box").style.top = ((document.body.parentNode.offsetHeight/2)-30)+"px";
	document.getElementById("load_box").style.left = ((document.body.parentNode.offsetWidth/2)-125)+"px";
}

function fixDocumentSizeLoop(x)
{	
	fixOverlaySize(); 
	fixLoadBoxSize();
	fixDocumentSizeLoopID = window.setTimeout("fixDocumentSizeLoop("+x+")", x); 
}

// Image Preloader
function preloadImages(srcArr)
{		
		imgArr = new Array();
		for(i=0; i<srcArr.length; i++)
		{
			if (document.images)
			{
				imgArr[i] = new Image(); 
				imgArr[i].src = srcArr[i]; 
			}
		}
}

