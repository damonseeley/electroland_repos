function Request (name, index, subindex, flags, len, type, i, id, refresh)
{
        this.name = name;
        this.index = index;
        this.subindex = subindex;
        this.flags = flags;
        this.len = len;
        this.type = type;
        this.i = i;
        this.id = id;
        this.refresh = refresh;
}

function GeneralInfo()
{
        this.hostname = "";
        this.hardware = "";
        this.os = "";
}

function EvalData(k, c_val, error)
{
    this.k=k;
    this.c_val=c_val;
    this.error=error;
}

/*/////////////////////////////////////////////////////////////////////////////////////////////////////////////*/
//for appended functions: displaytype=function, subindex=subindex, len=offset, array=0,1,2 (no, array, extended array)
function Variable (index, subindex, array, name, datatype, displaytype, editable, len, need)
{           
        this.index = index;
        this.array = array;
        this.name = name;
        this.datatype = datatype;
        this.editable = editable;
        this.subindex = subindex;
        this.len = len;
        
        if (datatype!="func" && displaytype=="")
          this.displaytype = datatype;
        else 
          this.displaytype = displaytype;

        this.need = need;
        this.disable = false;
}

function FuncVar (name, datatype, displaytype, type, len, disable, sidx)
{
        this.name = name;
        this.datatype = datatype;
        this.type = type;
        this.displaytype = displaytype;
        this.length = len;
        this.disable = disable;
        this.sidx=sidx;
}

function Function (name, index, variables, show, refresh)
{
        this.name = name;
        this.index = index;
        this.variables = variables;
        this.show = show;
        this.refresh = refresh;
}

function Module (mod_list_item)
{
		this.url = mod_list_item.url;
		this.type = mod_list_item.type;
		this.typeId = mod_list_item.typeId;
		this.name = mod_list_item.name;
		this.index = parseInt(mod_list_item.index);
		this.variables = new Array();
		this.functions = new Array();
		this.vcount = 0;
		this.fcount = 0;
		this.arrlens = new Array();
		this.arraynames = new Array();
		this.arrayindexes = new Array();
		this.editable = false;
		this.loop = "";
		this.extendedarray = -1;
		this.needreboot = false;
		this.favorites = null;
		this.loadscreen = false;
		this.interval = 5000;
		this.order = 999;
		this.customFolder = "";
		this.hide = false;
        
      switch (this.typeId)
      {                        
		case 1: // Access Control
				this.hide = true;
				break;
		case 2: //NIC
				this.order = 2;
				this.customFolder = "General";
				this.variables[this.vcount++] = new Variable(this.index+1,1,0,"Mac Address","string","",false,20,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,2,0,"IP Address","string","",true,20,4);
				this.variables[this.vcount++] = new Variable(this.index+1,3,0,"Subnet Mask","string","",true,20,4);
				this.variables[this.vcount++] = new Variable(this.index+1,4,0,"DHCP","bool","ed",true,1,-2);
				
				this.needreboot = true;
				
				this.functions[0] = new Function ("Release Address", this.index+12288, new Array(),1, false);       
           	break;
          case 3: //TIME
				this.order = 5;
				this.customFolder = "General";
				this.variables[this.vcount++] = new Variable(this.index+1,1,0,"SNTP Server","string","",true,255,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,2,0,"SNTP Refresh","int","days",true,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,3,0,"UTC Time","int","time",true,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,4,0,"DateTime","string","",false,40,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,5,0,"Timezone","int","timezone",true,2,-1);                       
				this.variables[this.vcount++] = new Variable(this.index+2,0,0,"Timezone Count","int","hidden",false,4,-1);                      
				break;                       
          case 4: //UserManagement
				this.order = 6;
				this.customFolder = "General";
				this.arrayindexes[0] = 0;
				
				this.variables[this.vcount++] = new Variable(this.index+1,1,1,"Name","string","",false,255,-1);
				// Don't show on win ce 
				if (winxp) this.variables[this.vcount++] = new Variable(this.index+2,1,1,"Domain","string","",false,255,-1);
				else       this.variables[this.vcount++] = new Variable(this.index+2,1,1,"Domain","string","hidden",false,255,-1);	  
				this.variables[this.vcount++] = new Variable(this.index,0,1,"Delete","func",1,false,0,-1);
				
				
				var fvars = new Array();
				var fvarcount = 0;
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",4,4,false,-1);
				fvars[2] = new FuncVar("sizedomain","int","hidden",5,4,false,-1);
				fvars[3] = new FuncVar("sizepassword","int","",6,4,false,-1);
				fvars[4] = new FuncVar("Name","string","",-2,0,false,-1);
				// Don't show on win ce 
				if (winxp) fvars[5] = new FuncVar("Domain","string","",-2,0,false,-1);
				else       fvars[5] = new FuncVar("Domain","string","hidden",-2,0,false,-1);
				fvars[6] = new FuncVar("Password","string","",-2,0,false,-1);
				
				this.functions[this.fcount++] = new Function ("Add User", this.index+12288, fvars, 1, true);
				
				
				fvars = new Array();					
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,1);
				fvars[2] = new FuncVar("sizedomain","int","",4,4,false,2);
				fvars[3] = new FuncVar("Name","string","",-2,0,false,1);
				fvars[4] = new FuncVar("Domain","string","",-2,0,false,2);
				
				this.functions[this.fcount++] = new Function ("Delete User", this.index+12289, fvars, 0, true);
				
				break;
			case 5: //RAS
				this.order = 15;
				this.arraynames[0] = "RAS Lines";
				this.arrayindexes[0] = 5;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Enable","bool","yn",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Slow Connection","bool","yn",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Get Addresses from","int","",true,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Static IP Count","int","",true,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Static IP Start","int","",true,4,-1);
				
				this.variables[this.vcount++] = new  Variable(this.index+2,1,1,"Name","string","",false,50,-1);
				this.variables[this.vcount++] = new  Variable(this.index+3,1,1,"Enabled","bool","line",false,1,-1);
				
				break;
			case 6: //FTP
				this.order = 16;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Active","bool","yn",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+2,1,0,"Allow Anonymous","bool","yn",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+3,1,0,"Allow Anonymous Upload","bool","ed",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+4,1,0,"Anonymous Vroots","bool","ed",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+5,1,0,"Use Authentification","bool","yn",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+6,1,0,"Default Directory","string","dir",true,255,-1);
				break;	
			case 7: //SMB
				this.customFolder = "General";
				this.order = 8;
				this.arrayindexes[0] = 0;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,1,"Name","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+2,1,1,"Path","string","dir",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index,0,1,"Delete","func",1,false,0,-1);
				
				
				var fvars = new Array();
				var fvarcount = 0;
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,-1);
				fvars[2] = new FuncVar("sizepath","int","",4,4,false,-1);
				fvars[3] = new FuncVar("Name","string","",-2,0,false,-1);
				fvars[4] = new FuncVar("Path","string","dir",-2,0,false,-1);
				
				this.functions[this.fcount++] = new Function ("Add Share", this.index+12288, fvars, 1, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				//fvars[0] = new FuncVar("sizename","int","",2,4,false,1);
				fvars[1] = new FuncVar("Name","string","",-2,0,false,1);
				
				this.functions[this.fcount++] = new Function ("Delete Share", this.index+12289, fvars, 0, true);
				this.loadscreen = true;
				break;
			case 8: //TwinCAT
				this.customFolder = "TwinCAT";
				this.order = 20;
				this.arraynames[0] = "TwinCAT Routes";
				this.arrayindexes[0] = 8;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Major Version","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,2,0,"Minor Version","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,3,0,"Build","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,4,0,"AMS Net Id","string","",false,20,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,5,0,"Reg Level","int","tcreglvl",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,6,0,"TwinCAT Status","int","tcstate",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,7,0,"RunAsDevice","bool","yn",true,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,8,0,"ShowTargetVisu","bool","yn",true,4,-1);
				this.variables[this.vcount] = new  Variable(this.index+2,1,2,"Name","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+3,1,2,"Address","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+4,1,2,"AMS","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+5,1,2,"Flag","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+6,1,2,"Timeout","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+7,1,2,"Transport","int","transport",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+8,0,2,"Delete","func",1,false,0,-1);
				
				var fvars = new Array();
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("Flags","int","routeflags",-2,4,false,-1);
				fvars[2] = new FuncVar("Timeout","int","",-2,4,false,-1);
				fvars[3] = new FuncVar("Transport","int","transport",-2,2,false,-1);
				fvars[4] = new FuncVar("NetId","netid","netid",-2,6,false,-1);
				fvars[5] = new FuncVar("sizename","int","",7,4,false,-1);
				fvars[6] = new FuncVar("sizeaddress","int","",8,4,false,-1);
				fvars[7] = new FuncVar("Name","string","",-2,0,false,-1);
				fvars[8] = new FuncVar("Address","string","",-2,0,false,-1);
				
				this.functions[0] = new Function ("Add Route", this.index+12288, fvars, 1, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("sizename","int","",1,4,false,2);
				fvars[1] = new FuncVar("Name","string","",-2,0,false,2);
				
				this.functions[1] = new Function ("Delete Route", this.index+12289, fvars, 0, true);
				
				break;
			case 9: //Data Store
				this.order = 22;
				var fvars = new Array();
				var fvarcount = 0;
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,-1);
				fvars[2] = new FuncVar("Path","string","dsvar",-2,0,false,-1);
				
				this.bidx=this.index+12288;
				
				this.functions[this.fcount++] = new Function ("Browse DataStore", this.index+12288, fvars, 2, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,-1);
				fvars[2] = new FuncVar("sizevalue","int","",4,4,false,-1);
				fvars[3] = new FuncVar("Name","string","",-2,0,false,-1);
				fvars[4] = new FuncVar("Value","string","",-2,0,false,-1);
				
				this.functions[this.fcount++] = new Function ("Add Item", this.index+12289, fvars, 1, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,-1);
				fvars[2] = new FuncVar("Name","string","",-2,0,false,-1);
				
				this.functions[this.fcount++] = new Function ("Delete Item", this.index+12290, fvars, 0, true);
				break;
			case 10: //Software
				this.customFolder = "General";
				this.order = 3;
				this.arrayindexes[0] = 0;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,1,"Name","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+2,1,1,"Company","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+3,1,1,"Date","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+4,1,1,"Version","string","",false,255,-1);                          
				break;
			case 11: //CPU
				this.customFolder = "General";
				this.order = 0;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"CPU Frequency (MHz)","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,2,0,"Current CPU Usage (%)","int","",false,4,-1);
				this.loop = "cpuloop";
				this.interval = 3000;
				break;
			case 12: //Memory
				this.customFolder = "General";
				this.order = 1;
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Program Memory Allocated","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,2,0,"Program Memory Storage","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,3,0,"Storage Memory Allocated","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,4,0,"Storage Memory Available","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,5,0,"Memory Devision","int","memdiv",false,4,-1);
				this.loop = "memoryloop";
				this.interval = 3000;
				break;
			case 13: //Logfile
				this.hide = true;
				break;
			case 14: //FirewallCE
				this.hide = true;
				/*this.order = 17;
				this.arraynames[0] = "Firewall Rules";
				this.arrayindexes[0] = 3;
				
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"IPv4","bool","ed",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,2,0,"IPv6","bool","ed",true,1,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,3,0,"Persist","bool","yn",true,1,-1);
				
				this.variables[this.vcount++] = new  Variable(this.index+2,1,2,"Flags","int","fwflags",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+3,1,2,"Mask","int","mask",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+4,1,2,"Private Host","string","",false,30,-1);
				this.variables[this.vcount++] = new  Variable(this.index+5,1,2,"Public Host","string","",false,30,-1);
				this.variables[this.vcount++] = new  Variable(this.index+6,1,2,"Public Host Mask","string","",false,30,-1);
				this.variables[this.vcount++] = new  Variable(this.index+7,1,2,"Protocol","int","protocol",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+8,1,2,"Action","int","fwaction",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+9,1,2,"Port Range","int","hl",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+10,1,2,"Type and Code","int","hl",false,4,-1);
				this.variables[this.vcount] = new  Variable(this.index+11,1,2,"Description","string","",false,255,-1);
				this.variables[this.vcount++] = new  Variable(this.index+12,1,2,"UID","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+13,0,2,"Delete","func",1,false,0,-1);
				
				
				var fvars = new Array();
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("Flags","int","fwflags",-2,4,false,-1);
				fvars[2] = new FuncVar("Mask","int","mask",-2,4,false,-1);
				fvars[3] = new FuncVar("Private Host","string","",-2,40,true,-1);
				fvars[4] = new FuncVar("Public Host","string","",-2,40,true,-1);
				fvars[5] = new FuncVar("Public Host Mask","string","subnetmask",-2,4,true,-1);
				fvars[6] = new FuncVar("Protocol","int","protocol",-2,4,true,-1);
				fvars[7] = new FuncVar("Actions","int","fwaction",-2,4,true,-1);
				fvars[8] = new FuncVar("Portrange","int","portrange",-2,4,true,-1);
				fvars[9] = new FuncVar("Type and Code","int","typecode",-2,2,true,-1);
				fvars[10] = new FuncVar("sizename","int","",11,4,false,-1);
				fvars[11] = new FuncVar("Description","string","",-2,0,false,-1);
				
				this.functions[0] = new Function ("Add Rule", this.index+12288, fvars, 1, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("UID","int","",-2,4,false,12);
				
				this.functions[1] = new Function ("Delete Rule", this.index+12289, fvars, 0, true);*/
				break;
			case 16: //FSO
				this.hide = true;
				break;
			case 17: //REGISTRY
				this.hide = true;
				break;
				case 18: //PLC
				this.customFolder = "TwinCAT";
				this.order = 21;
				var fvars = new Array();
				var fvarcount = 0;
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("sizename","int","",3,4,false,1);
				fvars[2] = new FuncVar("Path","string","plcvar",-2,0,false,1);
				
				this.functions[this.fcount++] = new Function ("Browse PLC", this.index+12290, fvars, 2, true);
				
				//this.functions[this.fcount++] = new Function ("Add Group", this.index+12289, new Array (new FuncVar("sizename","int","",1,4,false), new FuncVar("Name","string","",-2,0,false)), 1, true);
				
				fvars = new Array();
				fvars[0] = new FuncVar("SubIndex","int","",-2,4,false);
				
				this.functions[this.fcount++] = new Function ("Delete Group", this.index+12291, fvars, 0, true);                                                
				this.functions[this.fcount++] = new Function ("Delete Variable", this.index+12292, fvars, 0, true);
				this.bidx=this.index+12288;
				
				this.favorites=new Array();
				this.loadscreen = true;
				break; 
			case 19: //Display
				this.customFolder = "General";
				this.order = 4;
				this.variables[this.vcount++] = new Variable(this.index+1,1,0,"Current Resolution","int","resolution",true,4,-1);                      
				this.variables[this.vcount++] = new Variable(this.index+2,0,0,"Resolution Count","int","hidden",false,4,-1);
				this.needreboot = false;
				break;
			case 20: //EWF  
				this.hide = true;
				/*this.customFolder = "Write Filter";
				this.variables[this.vcount++] = new Variable(this.index+1,1,1,"Volume Name","string","",false,255,-1);
				this.variables[this.vcount++] = new Variable(this.index+2,1,1,"Volume ID","string","",false,255,-1);
				this.variables[this.vcount++] = new Variable(this.index+3,1,1,"State","int","ewf-state",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+4,1,1,"Type","int","ewf-type",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+5,1,1,"Boot command","int","ewf-bootcommand",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index,0,1,"commit","func",0,false,0,-1);
				
				var fvars = new Array();
				var fvarcount = 0;
				
				fvars[0] = new FuncVar("size","int","",-1,4,false,-1);
				fvars[1] = new FuncVar("commit","string","",-2,0,false,1);
				this.functions[this.fcount++] = new Function ("Commit / Disable - Live", this.index+12288, fvars, 0, true);
				*/
				break;
			case 21: //FBWF
				this.hide = true;
				/*this.customFolder = "Write Filter";
				this.arraynames[0] = "Volumes";
				this.arrayindexes[0] = 6;
				
				this.variables[this.vcount++] = new Variable(this.index+1,1,0,"State","int","",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,2,0,"Compression","int","",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+1,3,0,"PreAllocation","int","",false,4,-1);
				
				this.variables[this.vcount++] = new Variable(this.index+2,1,0,"Next State","int","",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+2,2,0,"Next Compression","int","",false,4,-1);
				this.variables[this.vcount++] = new Variable(this.index+2,3,0,"Next PreAllocation","int","",false,4,-1);
				
				//vol
				this.variables[this.vcount++] = new Variable(this.index+3,1,1,"Volume","string","",false,255,-1);
				this.variables[this.vcount++] = new Variable(this.index+4,1,1,"Exclusions","nstring","exclusion",false,255,-1);
				
				
				this.needreboot = true;*/
				break;
			case 22: // Regfilter
				this.hide = true;
				this.customFolder = "Write Filter";
				break; 
			case 23: //Silicon Drive 
				this.order = 9;
				this.customFolder = "General";
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Total EraseCounts","int","",false,8,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,2,0,"Drive Usage (%)","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,3,0,"Number of Spares","int","",false,4,-1);
				this.variables[this.vcount++] = new  Variable(this.index+1,4,0,"Spares Used","int","",false,4,-1);
				break;
			case 256: //Misc
				this.order = 7;
				this.customFolder = "General";
				this.variables[this.vcount++] = new  Variable(this.index+1,1,0,"Startup Numlock State","bool","ed",true,1,-1);
				
				var fvars = new Array();
				fvars[0] = new FuncVar("dummy","int","hidden",-2,1,false,-1);
				
				this.functions[0] = new Function ("Reboot", rebootindex, fvars, 2, false);
				
				if (!winxp)
				{
				var fvars = new Array();
				fvars[0] = new FuncVar("dummy","int","hidden",-2,1,false,-1);
				
				this.functions[1] = new Function ("Restore Factory Settings", this.index+12288, fvars, 1, false);
				}
				
				this.needreboot = false;
				break;    
				case 513: //Customer Pages
				this.order = 23;
				this.needreboot = false;
				break;                        
			}
        
			for (var i = 0; i < this.vcount; i++)
			{
			        if (this.variables[i].editable)
			        {
			                this.editable = true;
			                break;
			        }
			} 
        
        this.show = function (drawtable)
        {				
								window.scrollTo(0, 0); // Goto top of website
								
                if (this.typeId==513)
                {
                  show_customer_pages(this.name, this.url);
                  return;
                }
                if (this.loadscreen)
                {
                  load_start();
                }
                is_open=Array();
                var text = "";
                
                text = "<h2>"+this.name+"</h2>";
                
                debugln("Showing "+this.name+" with "+this.vcount+" variables and "+this.functions.length+" functions");
                
                if (this.favorites!=null)
                {
                    var plci = get_object("PLC");
                  
                    if (plci!=-1 && mod_list[plci].favorites!=null)
                    {                          
                      text += "<p><b>Filter Favorites:</b> <select id=\"favgroups\" onChange=\"favchange()\" style=\"z-index:0;\"><option value=\"none\">browse</option>";

                      for (var i=0; i<mod_list[plci].favorites.length; i++)
                      {
                         text += "<option value=\""+mod_list[plci].favorites[i]+"\">"+mod_list[plci].favorites[i]+"</option>";
                      }
                     
                      text += "</select></p><p id=\"cFavList\"></p>";
                    }
                }

                if (this.bidx)
                {
                    bidx = this.bidx;
                }
                if (this.vcount>0)
                {                    
                    if (this.variables[0].array==0)
                      text += "<table cellspacing=\"1\" class=\"datatable\" width=\"90%\" align=\"center\"><td class=\"toptable\" width=\"33%\">Name</td><td class=\"toptable\" width=\"67%\">Value</td></tr>";
                    
                    var hiddentags = "";
                    var lastIndex = 0;
                    var currentIndex = lastIndex;
                    var currentArray = 0;
                    var currentStart = 0;
                    
                    this.qidx = new Array();
                    this.qsidx = new Array();
                    this.qflag = new Array();
                    this.qlen = new Array();
                    this.qtype = new Array();
                    this.qiarr = new Array();
                    
                    
                    if (this.arrlens.length==0)
                    { 
                        var send = false; 
                        for (var i = 0; i < this.vcount; i++)
                        {
                          if (this.variables[i].array!=0)
                          {
                            this.qidx.push(this.variables[i].index);
                            this.qsidx.push(0);
                            this.qflag.push(0);
                            this.qlen.push(2);
                            this.qtype.push("int");
                            this.qiarr.push(-1);
                            send = true;
                          }
                        }
                        if (send)
                        {
                          query_readmultiple(this.qidx,this.qsidx,this.qflag,this.qlen,this.qtype,this.qiarr,"Arraylens",false);
                          return;   
                        }
                      }
                    
                      for (var i = 0; i < this.vcount; i++)
                      {
                          currentIndex = this.arrayindexes[currentArray];
                          if (this.variables[i].array==0)
                          {      
                              this.qidx.push(this.variables[i].index);
                              this.qsidx.push(this.variables[i].subindex);
                              this.qflag.push(0);
                              this.qlen.push(this.variables[i].len);
                              this.qtype.push(this.variables[i].datatype);
                              this.qiarr.push(-1);

                              if (this.variables[i].displaytype!="hidden")
                              {
                                  var icon="";
                                  switch (this.variables[i].displaytype)
                                  {
                                      case "date":
                                        icon = "Calendar";
                                        break;
                                      case "time":
                                        icon = "Time";
                                        break;
                                      case "dir":
                                      case "plcvar":
                                        icon = "OZ";
                                        break;
                                  }
                                  if (icon!="")
                                      icon = "<img alt=\"\" src=\"images/"+icon+".gif\" border=\"0\">";
                                  
                                  var tableclass="lockedtable";
                                  if (this.variables[i].editable)
                                      tableclass="normaltable";

				  												text += "<tr id=\"tr"+this.qsidx[i]+","+this.qidx[i]+"\"><td width=\"33%\" class=\"titletable\"><table width=\"100%\"><tr><td class=\"titletable\">"+this.variables[i].name+"</td><td class=\"titletable\" align=\"right\"><image title=\"Use the apply button to accept changes\" id=\"v"+this.qsidx[i]+","+this.qidx[i]+"info\" style=\"display:none;\" src=\"images/info.gif\" alt=\"changed\"></td><tr></table><td width=\"66%\" class=\""+tableclass+"\"><table width=\"100%\"><tr><td valign=\"top\">"+icon+"</td><td class=\""+tableclass+"\" width=\"100%\" id=\"v"+this.qsidx[i]+","+this.qidx[i]+"td\"><span style=\"width:100%; display: block;\" id=\"v"+this.qsidx[i]+","+this.qidx[i]+"\"></span></td></tr></table></tr>";

			      									}
                              else hiddentags += "<input type=\"hidden\" value=\"0\" id=\"v"+this.qsidx[i]+","+this.qidx[i]+"\">";
                              hiddentags += "<input type=\"hidden\" value=\"0\" id=\"v"+this.qsidx[i]+","+this.qidx[i]+"old\">";
                          }
                          else
                          {
                              if (this.arrayindexes[currentArray]!=null && i >= this.arrayindexes[currentArray])
                              {                                  
                                  if (currentArray == 0)
                                  {
                                    text += this.closeArray(-1,0,0,0);
                                  }
                                  else
                                  {
                                    text += this.closeArray(this.variables[i].array,this.arrlens[currentArray-1],(currentArray-1),this.arrayindexes[currentArray-1],i)
                                  }
                                  
                                  if (this.arraynames[currentArray])
                                    text += "<h3>"+this.arraynames[currentArray]+"</h3>";
                                  
                                  lastIndex = currentIndex;
                                  currentArray++;
                              }
                          }
                      }
                      
                      if (this.arrayindexes.length>0)
                        text += this.closeArray(this.variables[i-1].array,this.arrlens[currentArray-1],(currentArray-1),this.arrayindexes[currentArray-1],this.variables.length)+hiddentags;
                      else text += this.closeArray(-1,0,0,0)+hiddentags;
     
                      query_readmultiple(this.qidx,this.qsidx,this.qflag,this.qlen,this.qtype,this.qiarr,"Filltable",false);
                }
                else if (this.functions.length==0) show_info("Error: Not implemented","red");              
                
                for (var i = 0; i < this.functions.length; i++)
                {                                
                        if (this.functions[i].show!=0)
                        {
                                var hiddenfields = "";
                                text += "<span id=\"function"+i+"\"><h3>"+this.functions[i].name+"</h3><p><table class=\"datatable\" width=\"90%\" cellpadding=\"1\" cellspacing=\"1\" align=\"center\">"; 
                                for (var j = 0; j < this.functions[i].variables.length; j++)
                                {
                                       if (this.functions[i].variables[j].type==-2)
                                                text += "<tr "+(this.functions[i].variables[j].displaytype=="hidden"? "style=\"display: none\"":"")+"><td class=\"titletable\" width=\"33%\" valign=\"top\"><b>"+this.functions[i].variables[j].name+"</b></td><td class=\"normaltable\" width=\"66%\">"+format_add(this.functions[i].variables[j].displaytype,"a"+this.functions[i].variables[j].name,this.functions[i].variables[j].disable)+"</td></tr>";
                                }
                                if (this.functions[i].index==rebootindex) text += "</table><p align=\"center\"><input class=\"button\" type=\"submit\" onclick=\"doReboot(true)\" value=\""+this.functions[i].name+"\"></p>";
                                else text += "</table>";
                
                                if (this.functions[i].show!=2) text += "<p align=\"center\"><input class=\"button\" type=\"submit\" onclick=\"runfunction("+i+",-1,'f')\" id=\""+this.functions[i].index+"\" name=\""+this.functions[i].name+"\" value=\""+this.functions[i].name+"\"></p>";
                
                                text += hiddenfields+"</span>";
                        }
                }
        
                if (drawtable)   
                {       
												document.getElementById("current").innerHTML+=text;
                        if (g_interval) window.clearInterval(g_interval);
                        if (this.loop.length>0)
                        {
                          g_interval = window.setInterval(function () { if (mod.loop.length>0) eval(mod.loop+"();") }, mod.interval);
                        }             
                }       
 
 
                return;
        }
        
        this.closeArray = function(type, len, ca, start, end)
        {  
            var text = "";
            
            if (this.editable && type==-1)
                  text += "<p align=\"center\"><input class=\"button_disabled\" type=\"submit\" onclick=\"apply()\" id=\"apply\" name=\"apply\" value=\"Apply\" DISABLED></p>";
                       
            if (type == -1) return "</table>" + text;                                        
            if (len == 0) return text + "<p align=\"center\">no items available</p>";
            

            if (type==1)
            {
              text += "<table cellspacing=\"1\" class=\"datatable\" width=\"90%\" align=\"center\">";
              for (var i = start; i < end; i++) //add header
							{	
								if(this.variables[i].displaytype!="hidden")
									text += "<td class=\"toptable\">"+this.variables[i].name+"</td>";
								else	
									text += "<td class=\"toptable\" style=\"display:none;\">"+this.variables[i].name+"</td>";
							}
            }
            else
            {
              var sel = "";
              for (var j = 0; j < len; j++)
              {
                sel += "<option id=\"option"+(this.variables[start].subindex+i)+","+(this.variables[start].index)+"\" value=\""+j+"\">#"+(j+1)+"</option>";
              }
              text += "<table cellspacing=\"1\" class=\"datatable\" width=\"90%\" align=\"center\"><tr><td class=\"normaltable\"><select onchange=\"show_extended("+ca+",this.value)\">" + sel + "</select></td></tr><tr>";
            }
          
          var k = 0;
          for (var j = 0; j < len; j++)
          {
            if (type==1)
                text += "<tr id=\"tr"+j+"\">";
            else 
            {
                text += "<table id=\"extendedtable"+ca+"_"+j+"\" "+(j==0?"":"style=\"display:none\"")+" cellspacing=\"1\" class=\"datatable\" width=\"90%\" align=\"center\"><tr><td class=\"toptable\" colspan=\"2\" id=\"header"+(this.variables[this.arrayindexes[ca]].subindex+j)+","+this.variables[this.arrayindexes[ca]].subindex+"\"><b><u>#"+(j+1)+"</b></u></td></td>";
            }
            for (var i=start; i<end; i++)
            {
                  if (this.variables[i].datatype!="func")
                  {
                          this.qidx.push(this.variables[i].index);
                          this.qsidx.push(this.variables[i].subindex+j);
                          this.qflag.push(0);
                          this.qlen.push(this.variables[i].len);
                          this.qtype.push(this.variables[i].datatype);
                          this.qiarr.push(i);
                                
                          if (type==1)
			  									{	
															if(this.variables[i].displaytype!="hidden")
															text += "<td class=\"normaltable\" width=\"400\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"td\"><span style=\"width:100%; display: block;\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"\"></span></td>";
														 else
															 text += "<td class=\"normaltable\" style=\"display:none;\" width=\"400\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"td\"><span style=\"width:100%; display: block;\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"\"></span></td>";
													}
													else 
													{
															text += "<tr id=\"tr"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"\"><td class=\"normaltable\" width=\"40%\"><b>"+this.variables[i].name+"</b></td><td class=\"normaltable\" width=\"60%\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"td\"><span style=\"width:100%; display: block;\" id=\"a"+this.qsidx[this.qidx.length-1]+","+this.qidx[this.qidx.length-1]+"\"></span></td></tr>";
													}
		  						}
                  else
                  {
                          var tmp1, tmp2;
                          if (this.variables[i].subindex==-1)
                          {
                               tmp1 = j+1;
                               tmp2 = "s";
                          }
                          else
                          {
                               tmp1 = "a"+(this.variables[i].subindex+j+1);
                               tmp2 = "f";
                          }
                          if (type==1)
                          {
                              text += "<td class=\"normaltable\" width=\"400\" align=\"center\"><span style=\"width:100%; display: block;\"><input class=\"button\" type=\"submit\" onclick=\"runfunction("+this.variables[i].displaytype+",'"+tmp1+"','"+tmp2+"')\" name=\""+this.functions[this.variables[i].displaytype].name+"\" value=\""+this.functions[this.variables[i].displaytype].name+"\"></span></td>";
                          }
                          else text += "<tr><td class=\"normaltable\" colspan=\"2\" align=\"center\"><span style=\"width:100%; display: block;\"><input class=\"button\" type=\"submit\" onclick=\"runfunction("+this.variables[i].displaytype+",'"+tmp1+"','"+tmp2+"')\" name=\""+this.functions[this.variables[i].displaytype].name+"\" value=\""+this.functions[this.variables[i].displaytype].name+"\"></span></td></tr>";
                 }
               }
              }
              if (type==1)
                  text += "</tr>";
              else text+="</table>"
                       
              text += "</tr></table>";          
              return text;
        }
       

        this.run = function(i,id,f)
        {
                var len = 0;
                var lenpos = -1;
                var values = new Array(this.functions[i].variables.length);
                for (var j = 0; j < this.functions[i].variables.length; j++)
                {
                        if (this.functions[i].variables[j].type>=0)
                        {			
                                if (id!=-1) 
                                {
                                      values[j] = document.getElementById(id+","+(this.index+this.functions[i].variables[j].sidx)).innerHTML.length;
                                }
                                else values[j] = document.getElementById("a"+this.functions[i].variables[this.functions[i].variables[j].type].name).value.length;
                        }
                        else if (this.functions[i].variables[j].type==-1)
                        {
                                lenpos = j;
                        }
                        else
                        {
                                if (id!=-1) 
                                {
                                      if (f=="s")
                                        values[j] = id;
                                      else values[j] = document.getElementById(id+","+(this.index+this.functions[i].variables[j].sidx)).innerHTML;
                                }
                                else values[j] = document.getElementById("a"+this.functions[i].variables[j].name).value;
                                //else values[j] = document.getElementById("a"+id+","+(this.index+this.functions[i].variables[j].sidx)).innerHTML;
                        }
                        
                        if (this.functions[i].variables[j].displaytype=="dir" && values[j].charAt(values[j].length-1) == "\\")
                          values[j] = values[j].substring(0, values[j].length-1);

                        if (this.functions[i].variables[j].length!=0)
                            len += this.functions[i].variables[j].length;
                        else len += values[j].length;
                }
                if (lenpos!=-1)
                        values[lenpos] = len;
                        
                var data = new Array(); 
                for (var j = 0; j < values.length; j++)
                {
                      data = prepare_data(values[j],this.functions[i].variables[j].datatype, this.functions[i].variables[j].length,data); 
                }
                query_write(this.functions[i].index, 1, 2, data, "data", this.functions[i].refresh)
        }   
}

function editItem(i,val,id)
{
    this.i = i;
    this.val = val;
    this.id=id;
}

function mod_list_item(name, type, index, typeId)
{
        this.name = name;
        this.type = type;
        this.typeId = typeId;
        this.index = index;
				this.order = 999;
				this.customFolder = "";
				this.hide = false;
				this.favorites = null;
}

